// Твой email для формы (замени на свой)
var EMAIL = "your@email.com";

var html = document.documentElement;
var themeButton = document.getElementById("theme-button");

// ----- Светлая / тёмная тема -----
function setTheme(theme) {
  html.setAttribute("data-theme", theme);
  themeButton.textContent = theme === "light" ? "☾" : "☀";
  try {
    localStorage.setItem("theme", theme);
  } catch (error) {}
}

var savedTheme = "dark";
try {
  savedTheme = localStorage.getItem("theme") || "dark";
} catch (error) {}
setTheme(savedTheme);

themeButton.addEventListener("click", function () {
  setTheme(html.getAttribute("data-theme") === "light" ? "dark" : "light");
});

// ----- Форма контактов -----
document.getElementById("mail-link").href = "mailto:" + EMAIL;

document.getElementById("form").addEventListener("submit", function (event) {
  event.preventDefault();

  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var subject = document.getElementById("subject").value;
  var message = document.getElementById("message").value;

  var body = message + "\n\n" + name + " (" + email + ")";

  window.location.href =
    "mailto:" + EMAIL +
    "?subject=" + encodeURIComponent(subject) +
    "&body=" + encodeURIComponent(body);
});

// ----- Приветствие -----
var greeting = document.getElementById("greeting");
var askNameButton = document.getElementById("askName");

function getName() {
  try {
    return localStorage.getItem("visitorName");
  } catch (error) {
    return null;
  }
}

function showGreeting(name) {
  greeting.textContent = name ? "Привет, " + name + "!" : "Добро пожаловать!";
  askNameButton.textContent = name ? "Сменить имя" : "Представиться";
}

askNameButton.addEventListener("click", function () {
  var name = prompt("Как тебя зовут?");
  if (name === null) return; // нажали «Отмена» — ничего не меняем
  name = name.trim();
  try {
    if (name) {
      localStorage.setItem("visitorName", name);
    } else {
      localStorage.removeItem("visitorName");
    }
  } catch (error) {}
  showGreeting(name || null);
});

showGreeting(getName());

// ----- Бургер-меню -----
var burger = document.getElementById("hamburger");
var menu = document.getElementById("menu");

function closeMenu() {
  menu.classList.remove("open");
  burger.setAttribute("aria-expanded", "false");
  burger.setAttribute("aria-label", "Открыть меню");
}

burger.addEventListener("click", function () {
  var isOpen = menu.classList.toggle("open");
  burger.setAttribute("aria-expanded", String(isOpen));
  burger.setAttribute("aria-label", isOpen ? "Закрыть меню" : "Открыть меню");
});

// Закрываем меню по клику на пункт
menu.addEventListener("click", function (event) {
  if (event.target.tagName === "A") closeMenu();
});

// Закрываем по Esc
document.addEventListener("keydown", function (event) {
  if (event.key === "Escape") closeMenu();
});

// Закрываем при клике вне меню
document.addEventListener("click", function (event) {
  if (!menu.contains(event.target) && !burger.contains(event.target)) closeMenu();
});

// ----- Кнопка «Наверх» с очень плавной прокруткой -----
var toTop = document.getElementById("to-top");
var scrolling = false;

// Показываем кнопку, когда страница прокручена вниз
function toggleToTop() {
  toTop.classList.toggle("show", window.scrollY > 500);
}
window.addEventListener("scroll", toggleToTop, { passive: true });
toggleToTop();

function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function scrollToTop() {
  var start = window.scrollY;
  if (start === 0) return;

  // Без анимации, если в системе включено «уменьшить движение»
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    window.scrollTo(0, 0);
    return;
  }

  // Чем дальше до верха, тем дольше едем: от 1.2 до 2.5 секунд
  var duration = Math.min(2500, Math.max(1200, start * 0.6));
  var startTime = null;
  scrolling = true;
  html.style.scrollBehavior = "auto"; // отключаем встроенную, чтобы не мешала

  function step(time) {
    if (!scrolling) return finish();
    if (startTime === null) startTime = time;
    var progress = Math.min((time - startTime) / duration, 1);
    window.scrollTo(0, start * (1 - easeInOutCubic(progress)));
    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      finish();
    }
  }

  function finish() {
    scrolling = false;
    html.style.scrollBehavior = "";
  }

  requestAnimationFrame(step);
}

toTop.addEventListener("click", scrollToTop);

// Если пользователь сам крутит колесо или касается экрана — отменяем анимацию
["wheel", "touchstart", "keydown"].forEach(function (name) {
  window.addEventListener(name, function () {
    scrolling = false;
  }, { passive: true });
});
